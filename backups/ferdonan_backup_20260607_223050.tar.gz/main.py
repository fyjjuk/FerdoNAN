import os
import sys
import yaml
from core.logger import logger
from models.manifest import AgentManifest
from core.engine import FerdoNANEngine
from persistence.memory_store import ShortTermMemory
from core.tracing import generate_request_id
from services.intent_router import RouteNotFoundError
from security.ingress import IngressFilter
from security.egress import EgressFilter
from security.semantic_output import SemanticOutputFilter
from ui.selector import select_agent_interactive

def bootstrap_security_assets():
    if not os.path.exists("config"):
        os.makedirs("config")
    security_files = {
        "config/ingress_blacklist.txt": "# Blacklist de comandos peligrosos (RegEx)\nrm -rf\nsudo\npasswd\n",
        "config/egress_cmd_blacklist.txt": "# Comandos prohibidos en salida\nrm\ncurl\nwget\n",
        "config/egress_tools_blacklist.txt": "# Herramientas prohibidas\ndangerous_tool\n"
    }
    for filepath, default_content in security_files.items():
        if not os.path.exists(filepath):
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(default_content)
            logger.info(f"Archivo de seguridad creado: {filepath}")
    return True

def bootstrap_core():
    logger.info("Inicializando Núcleo de FerdoNAN...", extra={"component": "core"})
    bootstrap_security_assets()
    
    core_config = {}
    if os.path.exists("config/core.yaml"):
        with open("config/core.yaml", "r", encoding="utf-8") as f:
            core_config = yaml.safe_load(f) or {}
    
    ingress = IngressFilter(global_regex_path="config/ingress_blacklist.txt", enabled_layer2=False)
    egress = EgressFilter("config/egress_cmd_blacklist.txt", "config/egress_tools_blacklist.txt")
    semantic = SemanticOutputFilter(default_enabled=False)
    
    engine = FerdoNANEngine(ingress=ingress, egress=egress, semantic=semantic)
    engine.core_config = core_config
    # Inicializar RAG Engine para indexación automática
    from services.vector_store import RAGEngine
    engine.rag_engine = RAGEngine()
 
    # Inicializar RAG Engine para indexación automática
    from services.vector_store import RAGEngine
    engine.rag_engine = RAGEngine()
    
    agents_dir = "agents"
    loaded = {}
    
    if not os.path.exists(agents_dir):
        os.makedirs(agents_dir)
    
    for agent_id in os.listdir(agents_dir):
        path = os.path.join(agents_dir, agent_id)
        config_path = os.path.join(path, "config.yaml")
        if os.path.isdir(path) and os.path.exists(config_path):
            try:
                with open(config_path, "r", encoding="utf-8") as f:
                    data = yaml.safe_load(f)
                manifest = AgentManifest(**data)
                manifest.memory = ShortTermMemory(manifest.short_term_memory_window)
                manifest.llm_client = engine._get_llm_client(agent_id, data, core_config)
                # Indexar documentos de la carpeta docs/ del agente si existe
                docs_dir = os.path.join(path, "docs")
                if os.path.exists(docs_dir) and engine.rag_engine:
                    for doc_file in os.listdir(docs_dir):
                        if doc_file.endswith(('.txt', '.md', '.docx', '.xlsx')):
                            file_path = os.path.join(docs_dir, doc_file)
                            try:
                                engine.rag_engine.process_and_index(agent_id, file_path)
                                logger.info(f"Documento indexado: {doc_file} para agente {agent_id}")
                            except Exception as e:
                                logger.error(f"Error indexando {doc_file}: {e}")
                loaded[agent_id] = manifest
                logger.info(f"Agente {agent_id} cargado con éxito.", extra={"component": "core"})
            except Exception as e:
                logger.error(f"Error cargando agente {agent_id}: {e}", extra={"component": "core"})
    
    return engine, loaded

if __name__ == "__main__":
    engine, agents = bootstrap_core()
    generate_request_id()
    
    if not agents:
        print("❌ No se encontraron agentes configurados.")
        sys.exit(1)
    
    # Selección interactiva (menú con flechas)
    try:
        agent_manifest = select_agent_interactive(agents)
        if agent_manifest is None:
            print("👋 Selección cancelada. Saliendo...")
            sys.exit(0)
    except ImportError:
        # Fallback a selector numérico si prompt_toolkit no está instalado
        print("⚠️ prompt_toolkit no instalado. Usando selector numérico.")
        from main_old import select_agent
        agent_manifest = select_agent(agents)
    
    print(f"[+] Agente Activo: {agent_manifest.name} ({agent_manifest.id})")
    print(f"[+] Concurrencia: {agent_manifest.execution_mode}")
    print(f"[+] Proveedor LLM: {agent_manifest.llm_provider.get('name', 'desconocido')}")
    print("[+] Escribe 'salir' para finalizar.\n")
    
    while True:
        try:
            user_query = input(f"\n[{agent_manifest.id}] > ")
            if user_query.strip().lower() == 'salir':
                break
            if not user_query.strip():
                continue
            
            output, summary = engine.process_pipeline(agent_manifest, user_query)
            print(f"\n[Enrutamiento Exitoso]")
            print(f" -> Ruta: {summary.get('route_id', 'unknown')}")
            print(f" -> Modo: {summary.get('execution_mode', 'exclusive')}")
            print(f" -> Respuesta:\n{output}")
            
        except PermissionError as pe:
            print(f"\n[!] BLOQUEADO POR FIREWALL: {pe}")
        except RouteNotFoundError as exc:
            print(f"\n[!] Ruta no encontrada: {exc}")
            if hasattr(exc, 'available_routes') and exc.available_routes:
                print("   Rutas disponibles:")
                for r in exc.available_routes:
                    print(f"     - {r.get('route_id')}: {r.get('description', '')[:50]}")
        except KeyboardInterrupt:
            print("\n[!] Interrupción recibida. Saliendo...")
            break
        except Exception as e:
            print(f"[-] Error: {e}")
            logger.error(f"Error en pipeline: {e}", extra={"component": "main"})
