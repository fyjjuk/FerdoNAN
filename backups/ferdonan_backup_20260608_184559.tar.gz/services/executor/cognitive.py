import json
import re
from typing import Dict, Any, Optional
from core.logger import logger
from .base import BaseExecutor

class CognitiveExecutor(BaseExecutor):
    """Ejecuta rutas cognitivas usando el LLM del agente, con soporte para stages."""
    
    def _validate_stage_output(self, output: str, stage_name: str, output_key: str) -> bool:
        """Valida que la salida de una etapa no esté vacía y tenga contenido útil."""
        if output is None:
            logger.error(f"Stage '{stage_name}' produjo salida None para key '{output_key}'")
            return False
        if not output or not output.strip():
            logger.error(f"Stage '{stage_name}' produjo salida vacía para key '{output_key}'")
            return False
        return True

    def _execute_stage(self, agent_manifest, stage_config: Dict[str, Any], context: Dict[str, str], cleaned_input: str) -> tuple[str, Dict[str, str]]:
        """Ejecuta una etapa individual y actualiza el contexto."""
        # Usar el LLM del agente en lugar de crear uno nuevo
        llm = agent_manifest.llm_client
        
        prompt_template = stage_config.get("prompt", "{user_input}")
        system_prompt = stage_config.get("system_prompt", "")
        output_key = stage_config.get("output_key", f"stage_{stage_config.get('name', 'output')}")
        timeout = stage_config.get("timeout", 30)
        
        # Formatear prompt con el contexto actual
        try:
            formatted_prompt = prompt_template.format(**context, user_input=cleaned_input)
        except KeyError as e:
            logger.error(f"Falta clave en contexto para stage '{stage_config.get('name')}': {e}")
            return "", context
        
        # Configurar timeout en la llamada
        llm_config = {"timeout": timeout}
        
        try:
            output = llm.generate_response(formatted_prompt, system_prompt, llm_config)
            if self._validate_stage_output(output, stage_config.get('name', 'unnamed'), output_key):
                context[output_key] = output
            else:
                # Si la salida es inválida, reintentar una vez
                logger.warning(f"Stage '{stage_config.get('name')}' output inválido. Reintentando.")
                output = llm.generate_response(formatted_prompt, system_prompt, llm_config)
                if self._validate_stage_output(output, stage_config.get('name', 'unnamed'), output_key):
                    context[output_key] = output
                else:
                    context[output_key] = f"[ERROR: Stage '{stage_config.get('name')}' no produjo salida válida después de reintento]"
            return output, context
        except Exception as e:
            logger.error(f"Error en stage '{stage_config.get('name')}': {e}")
            context[output_key] = f"[ERROR: {str(e)}]"
            return f"Error: {str(e)}", context

    def execute(self, agent_manifest, route_data: Dict[str, Any], cleaned_input: str, router, rag_engine) -> str:
        # Si la ruta tiene stages, ejecutar secuencialmente
        stages = route_data.get("stages")
        if stages:
            logger.info(f"Ejecutando ruta con {len(stages)} stages")
            context = {}
            final_output = ""
            for stage in stages:
                stage_name = stage.get("name", "unknown")
                logger.debug(f"Ejecutando stage: {stage_name}")
                output, context = self._execute_stage(agent_manifest, stage, context, cleaned_input)
                final_output = output  # la última etapa será la respuesta final
            # Si hay una clave de salida específica en la ruta, usarla
            final_key = route_data.get("final_output_key", "respuesta_final")
            if final_key in context:
                return context[final_key]
            return final_output
        
        # Comportamiento original (sin stages)
        enhanced_prompt = cleaned_input
        if router.needs_rag_context(cleaned_input) and rag_engine:
            try:
                context_results = rag_engine.rag_query(agent_manifest.id, cleaned_input, top_k=3)
                if context_results and context_results.get('documents'):
                    context_text = "\n\n".join(context_results['documents'][0])
                    enhanced_prompt = f"Contexto relevante:\n{context_text}\n\nConsulta: {cleaned_input}"
                    logger.info(f"Contexto RAG inyectado ({len(context_text)} caracteres)")
            except Exception as e:
                logger.warning(f"Error consultando RAG: {e}")
        llm = agent_manifest.llm_client
        system_prompt = route_data.get("system_prompt", "Eres un asistente útil.")
        llm_config = route_data.get("model_config", {})
        output = llm.generate_response(enhanced_prompt, system_prompt, llm_config)
        return output
