import os
import yaml
from typing import List, Dict, Any, Tuple, Optional
from core.logger import logger
from services.router.factory import create_router

class RouteNotFoundError(Exception):
    def __init__(self, message: str, available_routes: List[Dict[str, Any]]):
        super().__init__(message)
        self.available_routes = available_routes

class Router:
    def __init__(self, mode: str = "keyword", model: Optional[str] = None, threshold: float = 0.3):
        self._config = {"mode": mode, "model": model, "threshold": threshold}
        self._router = create_router(self._config)

    def _load_agent_routes(self, agent_id: str) -> List[Dict[str, Any]]:
        routes_dir = os.path.join("agents", agent_id, "routes")
        routes = []
        if not os.path.exists(routes_dir):
            return routes
        for filename in os.listdir(routes_dir):
            if filename.endswith(".yaml") or filename.endswith(".yml"):
                with open(os.path.join(routes_dir, filename), "r") as f:
                    route_data = yaml.safe_load(f)
                    if route_data and "route_id" in route_data:
                        routes.append(route_data)
        return routes

    def needs_rag_context(self, query: str) -> bool:
        return False

    def route(self, agent_id: str, user_input: str, threshold: Optional[float] = None) -> Tuple[str, float, Dict]:
        routes = self._load_agent_routes(agent_id)
        if not routes:
            raise RouteNotFoundError("No hay rutas definidas para este agente.", [])
        result = self._router.route(routes, user_input, threshold)
        if result[0]:
            return result
        # Fallback a primera ruta
        default = routes[0]
        logger.debug(f"Usando ruta por defecto: {default['route_id']}")
        return default["route_id"], 0.5, default
