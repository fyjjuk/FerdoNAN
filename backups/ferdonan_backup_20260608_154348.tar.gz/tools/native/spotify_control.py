import subprocess
import sys
import json

def main():
    if len(sys.argv) < 2:
        print("Uso: python spotify_control.py '{\"action\": \"play\"}'")
        sys.exit(1)
    args = json.loads(sys.argv[1])
    action = args.get("action", "")
    
    action_map = {
        "play": "play",
        "pause": "pause",
        "stop": "pause",
        "pausa": "pause",
        "next": "next",
        "siguiente": "next",
        "prev": "previous",
        "anterior": "previous",
        "status": "status",
        "estado": "status"
    }
    cmd = action_map.get(action, action)
    
    try:
        if cmd == "play":
            subprocess.run(["playerctl", "--player=spotify", "play"], check=True)
            print("▶️ Reproduciendo")
        elif cmd == "pause":
            subprocess.run(["playerctl", "--player=spotify", "pause"], check=True)
            print("⏸️ Pausado")
        elif cmd == "next":
            subprocess.run(["playerctl", "--player=spotify", "next"], check=True)
            print("⏭️ Siguiente canción")
        elif cmd == "previous":
            subprocess.run(["playerctl", "--player=spotify", "previous"], check=True)
            print("⏮️ Canción anterior")
        elif cmd == "status":
            result = subprocess.run(["playerctl", "--player=spotify", "status"], capture_output=True, text=True)
            status = result.stdout.strip()
            if status == "Playing":
                print("▶️ Reproduciendo")
            elif status == "Paused":
                print("⏸️ Pausado")
            else:
                print("⏹️ Detenido o no disponible")
        else:
            print(f"Comando desconocido: {action}")
    except subprocess.CalledProcessError:
        print("❌ Spotify no está abierto o no se pudo controlar")
    except Exception as e:
        print(f"Error: {str(e)}")

if __name__ == "__main__":
    main()
