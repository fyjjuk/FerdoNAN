import subprocess
import shutil
import sys
import urllib.parse

def run(input_data: dict) -> dict:
    playlist_name = input_data.get("playlist", "")
    if not playlist_name:
        return {"error": "No se especificó playlist"}
    
    # Buscar spotify en el sistema
    spotify_cmd = None
    if shutil.which("spotify"):
        spotify_cmd = "spotify"
    elif shutil.which("flatpak"):
        spotify_cmd = "flatpak run com.spotify.Client"
    
    if not spotify_cmd:
        return {"error": "Spotify no está instalado"}
    
    # Codificar nombre para URI
    encoded_name = urllib.parse.quote(playlist_name)
    uri = f"spotify:search:{encoded_name}%20playlist"
    
    try:
        # Abrir búsqueda de la playlist en Spotify
        subprocess.Popen([spotify_cmd, "--uri=" + uri])
        return {"success": True, "message": f"🔍 Buscando playlist '{playlist_name}' en Spotify. Selecciona la playlist y dale play."}
    except Exception as e:
        return {"error": str(e)}

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Uso: python spotify_playlist.py 'nombre de la playlist'")
        sys.exit(1)
    result = run({"playlist": sys.argv[1]})
    print(result.get("message", result.get("error", "")))
