import json
from typing import Dict, Any
from core.logger import logger
from .base import BaseExecutor

class CognitiveExecutor(BaseExecutor):
    """Ejecuta rutas cognitivas usando el LLM del agente."""
    def execute(self, agent_manifest, route_data: Dict[str, Any], cleaned_input: str, router, rag_engine) -> str:
        enhanced_prompt = cleaned_input
        if router.needs_rag_context(cleaned_input) and rag_engine:
            try:
                context_results = rag_engine.rag_query(agent_manifest.id, cleaned_input, top_k=3)
                if context_results and context_results.get('documents'):
                    context_text = "\n\n".join(context_results['documents'][0])
                    enhanced_prompt = f"Contexto relevante:\n{context_text}\n\nConsulta: {cleaned_input}"
                    logger.info(f"Contexto RAG inyectado ({len(context_text)} caracteres)")
            except Exception as e:
                logger.warning(f"Error consultando RAG: {e}")
        llm = agent_manifest.llm_client
        system_prompt = route_data.get("system_prompt", "Eres un asistente útil.")
        llm_config = route_data.get("model_config", {})
        # Soporte para streaming si la ruta lo indica
        if route_data.get("stream", False):
            # El cliente LLM ya maneja streaming internamente
            pass
        output = llm.generate_response(enhanced_prompt, system_prompt, llm_config)
        return output
