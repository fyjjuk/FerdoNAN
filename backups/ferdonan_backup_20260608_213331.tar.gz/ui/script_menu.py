#!/usr/bin/env python3
"""
Menú interactivo de utilidades y scripts.
Permite ejecutar herramientas de backup, exportación, health check, etc.
"""
import subprocess
import sys
import os

# Lista de scripts disponibles (escalable: añade nuevas tuplas)
SCRIPTS = [
    ("Backup del proyecto", "python scripts/user/backup_cli.py crear"),
    ("Ver logs en tiempo real", "python scripts/user/logs_tail.py"),
    ("Health check", "python scripts/diagnostic/check_health.py"),
    ("Buscar archivos duplicados", "python scripts/diagnostic/find_duplicates.py"),
    ("Mapear estructura del proyecto", "python scripts/diagnostic/audit_project.py"),
    ("Exportar proyecto completo", "python scripts/user/export_project.py"),
    ("Limpiar archivos temporales", "python scripts/diagnostic/clean_project.py"),
]

def run_script(command):
    """Ejecuta un comando en el shell y muestra la salida."""
    print(f"\n⏳ Ejecutando: {command}\n")
    try:
        result = subprocess.run(command, shell=True, text=True)
        if result.returncode != 0:
            print(f"\n⚠️ El script terminó con código {result.returncode}")
    except Exception as e:
        print(f"\n❌ Error al ejecutar: {e}")
    input("\nPresiona Enter para continuar...")

def show_menu():
    """Muestra el menú y maneja la selección."""
    while True:
        print("\n" + "="*60)
        print("🛠️  MENÚ DE UTILIDADES FERDONAN")
        print("="*60)
        for idx, (name, _) in enumerate(SCRIPTS, start=1):
            print(f"  {idx}. {name}")
        print("  0. Volver al selector de agentes")
        print("="*60)
        
        choice = input("\n👉 Elige una opción: ").strip()
        if choice == "0":
            break
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(SCRIPTS):
                run_script(SCRIPTS[idx][1])
            else:
                print("❌ Opción inválida")
        except ValueError:
            print("❌ Entrada inválida. Ingresa un número o 0 para salir.")

def run():
    """Punto de entrada del menú."""
    show_menu()
