import json
import re
from typing import Dict, Any, Optional
from core.logger import logger
from .base import BaseExecutor

class CognitiveExecutor(BaseExecutor):
    """Ejecuta rutas cognitivas usando el LLM del agente, con soporte para stages."""
    
    def _validate_stage_output(self, output: str, stage_name: str, output_key: str) -> bool:
        """Valida que la salida de una etapa no esté vacía y tenga contenido útil."""
        if not output or not output.strip():
            logger.error(f"Stage '{stage_name}' produjo salida vacía para key '{output_key}'")
            return False
        # Si se espera un JSON, validar estructura (simplificado)
        if output.strip().startswith('{') and output.strip().endswith('}'):
            try:
                json.loads(output)
            except:
                logger.warning(f"Stage '{stage_name}' output no es JSON válido, pero se permite")
        return True

    def _execute_stage(self, agent_manifest, stage_config: Dict[str, Any], context: Dict[str, str], cleaned_input: str) -> tuple[str, Dict[str, str]]:
        """Ejecuta una etapa individual y actualiza el contexto."""
        provider = stage_config.get("provider", "ollama")
        model = stage_config.get("model")
        prompt_template = stage_config.get("prompt", "{user_input}")
        system_prompt = stage_config.get("system_prompt", "")
        output_key = stage_config.get("output_key", f"stage_{stage_config.get('name', 'output')}")
        timeout = stage_config.get("timeout", 30)
        
        # Formatear prompt con el contexto actual
        try:
            formatted_prompt = prompt_template.format(**context, user_input=cleaned_input)
        except KeyError as e:
            logger.error(f"Falta clave en contexto para stage '{stage_config.get('name')}': {e}")
            return "", context
        
        # Obtener el cliente LLM apropiado según el proveedor
        if provider == "ollama":
            from services.llm_providers import OllamaClient
            llm_config = {"model": model or "phi3:mini", "temperature": 0.7, "max_tokens": 2048}
            llm = OllamaClient(agent_manifest.id, llm_config, {})
        elif provider == "gemini":
            from services.llm_providers import GeminiClient
            llm_config = {"model": model or "gemini-1.5-flash"}
            llm = GeminiClient(agent_manifest.id, llm_config, agent_manifest.llm_provider)
        elif provider == "groq":
            from services.llm_providers import GroqClient
            llm_config = {"model": model or "llama3-8b-8192"}
            llm = GroqClient(agent_manifest.id, llm_config, agent_manifest.llm_provider)
        else:
            # Fallback a cliente por defecto del agente
            llm = agent_manifest.llm_client
        
        try:
            output = llm.generate_response(formatted_prompt, system_prompt, {"timeout": timeout})
            if self._validate_stage_output(output, stage_config.get('name', 'unnamed'), output_key):
                context[output_key] = output
            else:
                # Si la salida es inválida, intentar un reintento con un prompt más estricto
                logger.warning(f"Stage '{stage_config.get('name')}' output inválido. Reintentando con prompt corregido.")
                retry_prompt = f"La salida anterior fue inválida. Vuelve a generar la respuesta solicitada con el formato correcto.\nInstrucción original: {formatted_prompt}"
                output = llm.generate_response(retry_prompt, system_prompt, {"timeout": timeout})
                if output and output.strip():
                    context[output_key] = output
                else:
                    context[output_key] = f"[ERROR: Stage '{stage_config.get('name')}' no produjo salida válida]"
            return output, context
        except Exception as e:
            logger.error(f"Error en stage '{stage_config.get('name')}': {e}")
            context[output_key] = f"[ERROR: {str(e)}]"
            return f"Error: {str(e)}", context

    def execute(self, agent_manifest, route_data: Dict[str, Any], cleaned_input: str, router, rag_engine) -> str:
        # Si la ruta tiene stages, ejecutar secuencialmente
        stages = route_data.get("stages")
        if stages:
            logger.info(f"Ejecutando ruta con {len(stages)} stages")
            context = {}
            final_output = ""
            for stage in stages:
                stage_name = stage.get("name", "unknown")
                logger.debug(f"Ejecutando stage: {stage_name}")
                output, context = self._execute_stage(agent_manifest, stage, context, cleaned_input)
                final_output = output  # la última etapa será la respuesta final
            # Si hay una clave de salida específica en la ruta, usarla
            final_key = route_data.get("final_output_key", "respuesta_final")
            if final_key in context:
                return context[final_key]
            return final_output
        
        # Comportamiento original (sin stages)
        enhanced_prompt = cleaned_input
        if router.needs_rag_context(cleaned_input) and rag_engine:
            try:
                context_results = rag_engine.rag_query(agent_manifest.id, cleaned_input, top_k=3)
                if context_results and context_results.get('documents'):
                    context_text = "\n\n".join(context_results['documents'][0])
                    enhanced_prompt = f"Contexto relevante:\n{context_text}\n\nConsulta: {cleaned_input}"
                    logger.info(f"Contexto RAG inyectado ({len(context_text)} caracteres)")
            except Exception as e:
                logger.warning(f"Error consultando RAG: {e}")
        llm = agent_manifest.llm_client
        system_prompt = route_data.get("system_prompt", "Eres un asistente útil.")
        llm_config = route_data.get("model_config", {})
        output = llm.generate_response(enhanced_prompt, system_prompt, llm_config)
        return output
