import requests
import json
import time
from .base import LLMClient
from core.logger import logger

class OllamaClient(LLMClient):
    def generate_response(self, prompt: str, system_prompt: str, config: dict, stream: bool = True) -> str:
        model = config.get("model", "phi3:mini")
        url = "http://localhost:11434/api/generate"
        payload = {
            "model": model,
            "prompt": prompt,
            "system": system_prompt,
            "stream": stream,
            "options": {
                "temperature": config.get("temperature", 0.7),
                "num_predict": config.get("max_tokens", 2048)
            }
        }
        try:
            if stream:
                response = requests.post(url, json=payload, stream=True, timeout=30)
                response.raise_for_status()
                print("\n[🤖 IA]: ", end='', flush=True)
                full_output = ""
                for line in response.iter_lines():
                    if line:
                        try:
                            data = json.loads(line.decode('utf-8'))
                            token = data.get("response", "")
                            if token:
                                print(token, end='', flush=True)
                                full_output += token
                            if data.get("done"):
                                break
                        except:
                            pass
                print()
                return full_output
            else:
                response = requests.post(url, json=payload, timeout=30)
                response.raise_for_status()
                data = response.json()
                output = data.get("response", "")
                print(f"\n[🤖 IA]: {output}")
                return output
        except Exception as e:
            error_msg = f"Error: {str(e)}"
            print(f"\n[❌ ERROR]: {error_msg}")
            return error_msg
