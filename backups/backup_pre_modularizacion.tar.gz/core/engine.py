from typing import Tuple, Dict, Any
from core.logger import logger
from core.router import Router, RouteNotFoundError
from core.sanitizer import Sanitizer
from core.scheduler import ResourceScheduler
from modules.firewall.ingress import IngressFilter
from modules.firewall.egress import EgressFilter
from modules.firewall.semantic_output import SemanticOutputFilter

class FerdoNANEngine:
    def __init__(self, ingress: IngressFilter, egress: EgressFilter, semantic: SemanticOutputFilter):
        self.router = Router(mode="ollama")
        self.sanitizer = Sanitizer(enabled=True)
        self.ingress = ingress
        self.egress = egress
        self.semantic = semantic
        self.scheduler = ResourceScheduler()
        self.core_config = {}
        self.rag_engine = None  # se inyectará después

    def set_rag_engine(self, rag_engine):
        self.rag_engine = rag_engine
        # Actualizar el router con los dominios del agente
        # (opcional: se puede hacer por agente, queda pendiente)

    def _get_llm_client(self, agent_id: str, manifest_data: dict, core_config: dict):
        from core.llm_client import OllamaClient, GeminiClient, GroqClient, LocalClient
        provider = manifest_data.get("llm_provider", {}).get("name", "ollama")
        provider_config = manifest_data.get("llm_provider", {})
        if provider == "ollama":
            return OllamaClient(agent_id, provider_config, core_config)
        elif provider == "gemini":
            if not provider_config.get("api_key") and core_config.get("llm", {}).get("gemini", {}).get("api_key"):
                provider_config["api_key"] = core_config["llm"]["gemini"]["api_key"]
            return GeminiClient(agent_id, provider_config, core_config)
        elif provider == "groq":
            if not provider_config.get("api_key") and core_config.get("llm", {}).get("groq", {}).get("api_key"):
                provider_config["api_key"] = core_config["llm"]["groq"]["api_key"]
            return GroqClient(agent_id, provider_config, core_config)
        else:
            return LocalClient(agent_id, provider_config, core_config)

    def process_pipeline(self, agent_manifest, raw_input: str) -> Tuple[str, Dict[str, Any]]:
        cleaned_input = self.sanitizer.clean(raw_input)
        firewall_override = getattr(agent_manifest, 'firewall_override', {})
        if not self.ingress.evaluate(cleaned_input, firewall_override):
            raise PermissionError("Entrada bloqueada por Firewall Ingress.")

        can_parallel, reason = self.scheduler.can_run_parallel(agent_manifest)
        effective_mode = "parallel" if can_parallel else self.scheduler.suggest_degradation(agent_manifest.id)
        logger.info(f"PIPELINE_START: agent_id={agent_manifest.id}, mode={effective_mode}")

        # Router (obtiene la ruta)
        try:
            route_id, confidence, route_data = self.router.route(agent_manifest.id, cleaned_input)
        except RouteNotFoundError as e:
            logger.warning(f"Router: {str(e)}")
            raise

        # Decidir si añadir contexto RAG
        enhanced_prompt = cleaned_input
        if self.router.needs_rag_context(cleaned_input):
            logger.info(f"RAG activado para consulta: {cleaned_input[:50]}...")
            if self.rag_engine:
                try:
                    context_results = self.rag_engine.rag_query(agent_manifest.id, cleaned_input, top_k=3)
                    if context_results and context_results.get('documents'):
                        context_text = "\n\n".join(context_results['documents'][0])
                        enhanced_prompt = f"Contexto relevante:\n{context_text}\n\nConsulta: {cleaned_input}"
                        logger.info(f"Contexto RAG inyectado ({len(context_text)} caracteres)")
                except Exception as e:
                    logger.warning(f"Error consultando RAG: {e}")
            else:
                logger.warning("RAG Engine no disponible, continuando sin contexto")

        # Ejecutar ruta con LLM
        llm = agent_manifest.llm_client
        system_prompt = route_data.get("system_prompt", "Eres un asistente útil.")
        llm_config = route_data.get("model_config", {})
        output = llm.generate_response(enhanced_prompt, system_prompt, llm_config)

        if not self.egress.evaluate(output, route_data):
            return "ERROR_SEGURIDAD_EGRESS", {"status": "blocked", "route_id": route_id}
        output = self.semantic.evaluate_and_replace(output, route_data)

        return output, {
            "route_id": route_id,
            "confidence": confidence,
            "execution_mode": effective_mode
        }
