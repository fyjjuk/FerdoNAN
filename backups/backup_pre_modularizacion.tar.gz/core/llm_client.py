import os
import abc
import requests
import json
from typing import Dict, Any
from core.logger import logger
from core.tracing import get_request_id

class LLMClient(abc.ABC):
    def __init__(self, agent_id: str, provider_config: Dict[str, Any], core_config: Dict[str, Any]):
        self.agent_id = agent_id
        self.provider_config = provider_config
        self.core_config = core_config
        self.api_key = self._resolve_api_key()

    @abc.abstractmethod
    def generate_response(self, prompt: str, system_prompt: str, config: Dict[str, Any]) -> str:
        pass

    def _resolve_api_key(self) -> str:
        provider_name = self.__class__.__name__.replace("Client", "").upper()
        # Primero de la configuración del agente, luego de variables de entorno
        if self.provider_config.get("api_key"):
            return self.provider_config["api_key"]
        env_var = f"{provider_name}_API_KEY"
        return os.getenv(env_var, "")

    def _log_telemetry(self, provider: str, model: str, ti: int, to: int):
        logger.info("Telemetría de tokens", extra={
            "component": "llm_client",
            "request_id": get_request_id(),
            "provider": provider,
            "model": model,
            "tokens_input": ti,
            "tokens_output": to,
            "agent_id": self.agent_id
        })

class OllamaClient(LLMClient):
    """Cliente para modelos locales servidos por Ollama (http://localhost:11434)"""
    def generate_response(self, prompt: str, system_prompt: str, config: Dict[str, Any]) -> str:
        model = config.get("model", "llama3.2:3b")
        url = "http://localhost:11434/api/generate"
        payload = {
            "model": model,
            "prompt": prompt,
            "system": system_prompt,
            "stream": False,
            "options": {
                "temperature": config.get("temperature", 0.7),
                "num_predict": config.get("max_tokens", 2048)
            }
        }
        try:
            response = requests.post(url, json=payload, timeout=60)
            response.raise_for_status()
            data = response.json()
            output = data.get("response", "")
            # Ollama no devuelve conteo de tokens fácil, simulamos
            ti = len(prompt.split()) + len(system_prompt.split())
            to = len(output.split())
            self._log_telemetry("ollama", model, ti, to)
            return output
        except Exception as e:
            logger.error(f"Error en Ollama: {e}")
            return f"Error: {str(e)}"

class GeminiClient(LLMClient):
    def generate_response(self, prompt, system_prompt, config) -> str:
        import google.generativeai as genai
        genai.configure(api_key=self.api_key)
        model_name = config.get("model", "gemini-1.5-flash")
        model = genai.GenerativeModel(model_name=model_name, system_instruction=system_prompt)
        response = model.generate_content(prompt)
        self._log_telemetry("gemini", model_name,
                            response.usage_metadata.prompt_token_count,
                            response.usage_metadata.candidates_token_count)
        return response.text

class GroqClient(LLMClient):
    def generate_response(self, prompt, system_prompt, config) -> str:
        from groq import Groq
        client = Groq(api_key=self.api_key)
        model_name = config.get("model", "llama3-8b-8192")
        chat_completion = client.chat.completions.create(
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt}
            ],
            model=model_name,
            temperature=config.get("temperature", 0.7),
            max_tokens=config.get("max_tokens", 2048)
        )
        self._log_telemetry("groq", model_name,
                            chat_completion.usage.prompt_tokens,
                            chat_completion.usage.completion_tokens)
        return chat_completion.choices[0].message.content

# Cliente mock para pruebas sin LLM real
class LocalClient(LLMClient):
    def generate_response(self, prompt, system_prompt, config) -> str:
        ti, to = 10, 20
        self._log_telemetry("local", "mock", ti, to)
        return f"[Mock] Respuesta de {self.agent_id}: {prompt[:50]}..."
