import re
import requests
from core.logger import logger

class Sanitizer:
    def __init__(self, enabled: bool = True, model: str = "llama3.2:3b", use_llm_threshold: int = 50):
        self.enabled = enabled
        self.model = model
        self.use_llm_threshold = use_llm_threshold  # si input < 50 chars, no usar LLM
        self.ollama_url = "http://localhost:11434/api/generate"

    def _simple_clean(self, text: str) -> str:
        """Limpieza básica sin LLM (rápida)."""
        # Eliminar espacios múltiples, saltos de línea excesivos, caracteres no imprimibles
        text = text.strip()
        text = re.sub(r'\s+', ' ', text)
        text = re.sub(r'[^\x20-\x7EáéíóúñÑüÜ¿?¡!]', '', text)
        return text

    def _llm_clean(self, text: str) -> str:
        """Usa LLM para limpiar consultas largas/complejas."""
        prompt = f"""Limpia esta consulta eliminando muletillas, ruido y ambigüedades. Devuelve SOLO el texto limpio, sin explicaciones ni comillas.

Consulta: "{text}"
Texto limpio:"""
        try:
            response = requests.post(
                self.ollama_url,
                json={"model": self.model, "prompt": prompt, "stream": False, "options": {"temperature": 0.0, "num_predict": 200}},
                timeout=15
            )
            cleaned = response.json().get("response", "").strip()
            # Eliminar posibles prefijos residuales
            cleaned = re.sub(r'^(Texto limpio:|La consulta limpia es:|Claro, aquí está:)\s*', '', cleaned, flags=re.IGNORECASE)
            cleaned = cleaned.strip('"\'')
            return cleaned if cleaned else text
        except Exception as e:
            logger.warning(f"Sanitizador LLM falló: {e}, usando limpieza simple")
            return self._simple_clean(text)

    def clean(self, user_input: str) -> str:
        if not self.enabled:
            return user_input
        # Si la entrada es corta, no vale la pena usar LLM
        if len(user_input) < self.use_llm_threshold:
            cleaned = self._simple_clean(user_input)
            logger.debug(f"Sanitizador (simple): '{user_input}' -> '{cleaned}'")
            return cleaned
        cleaned = self._llm_clean(user_input)
        logger.info(f"Sanitizador (LLM): '{user_input}' -> '{cleaned}'")
        return cleaned
