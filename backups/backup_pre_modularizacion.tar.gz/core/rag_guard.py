import os
from typing import List
from sentence_transformers import SentenceTransformer, util
from core.logger import logger

class RAGGuard:
    """Clasificador rápido que determina si una consulta necesita buscar en documentos locales (RAG)."""
    def __init__(self, domains: List[str], model_name: str = 'all-MiniLM-L6-v2', threshold: float = 0.6):
        """
        domains: lista de frases que describen los temas de los documentos (ej. "estadísticas de monstruos", "hechizos").
        threshold: umbral de similitud por encima del cual se activa RAG.
        """
        self.threshold = threshold
        self.model = SentenceTransformer(model_name)
        self.domain_embeddings = self.model.encode(domains, convert_to_tensor=True)
        logger.info(f"RAGGuard inicializado con {len(domains)} dominios, umbral={threshold}")

    def needs_rag(self, query: str) -> bool:
        """Retorna True si la consulta debe pasar por RAG, False si puede responderse sin contexto adicional."""
        query_embed = self.model.encode(query, convert_to_tensor=True)
        scores = util.cos_sim(query_embed, self.domain_embeddings)[0]
        max_score = float(scores.max())
        logger.debug(f"RAGGuard: query='{query[:50]}...', max_sim={max_score:.3f}, needed={max_score >= self.threshold}")
        return max_score >= self.threshold
